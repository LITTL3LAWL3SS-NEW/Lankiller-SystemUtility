This is a tool that disables LanSchool and uses a loophole that I have found. 
This only works once per session and when you restart or turn off your computer you need to run the script again
When you run it and encounter an error it normaly means that lanschool is already disabled and you should be fine.
I would always run this twice and then periodicly just in case it restarts for some reason.

How to use:
Run the .bat file and click yes to allow changes. Would recommend changing the name to "add_printer" and put it inside your download folder
Another place I would recommend is to put it within some system folders if you can.

*Disclaimer: I am not responsible for what you do with this. It is Your own fault if you get caught. USE AT YOUR OWN RISK. Good Luck